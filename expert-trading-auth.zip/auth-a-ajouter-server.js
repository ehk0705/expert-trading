/*
    AUTHENTIFICATION À AJOUTER DANS server.js
    Dépendances à installer :
    npm install bcryptjs jsonwebtoken

    Variables d'environnement Render recommandées :
    JWT_SECRET=une_phrase_longue_et_unique
    AUTH_ADMIN_USER=admin
    AUTH_ADMIN_PASSWORD=mot_de_passe_solide

    Important :
    - Ne jamais stocker un mot de passe en clair.
    - La colonne password_hash contient le mot de passe chiffré.
    - Ce bloc suppose que ton server.js possède déjà :
      const express = require("express");
      const { Pool } = require("pg");
      const app = express();
      const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
*/

const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || "CHANGEZ_CE_SECRET_EN_PRODUCTION";
const AUTH_ADMIN_USER = process.env.AUTH_ADMIN_USER || "";
const AUTH_ADMIN_PASSWORD = process.env.AUTH_ADMIN_PASSWORD || "";

async function creerTableUtilisateursSiBesoin() {
    await pool.query(`
        CREATE TABLE IF NOT EXISTS app_user (
            id SERIAL PRIMARY KEY,
            username VARCHAR(80) NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
    `);

    if (AUTH_ADMIN_USER && AUTH_ADMIN_PASSWORD) {
        const existe = await pool.query(
            "SELECT id FROM app_user WHERE username = $1",
            [AUTH_ADMIN_USER]
        );

        if (existe.rowCount === 0) {
            const hash = await bcrypt.hash(AUTH_ADMIN_PASSWORD, 12);

            await pool.query(
                "INSERT INTO app_user (username, password_hash) VALUES ($1, $2)",
                [AUTH_ADMIN_USER, hash]
            );

            console.log("Utilisateur administrateur créé :", AUTH_ADMIN_USER);
        }
    }
}

function creerTokenUtilisateur(user) {
    return jwt.sign(
        {
            id: user.id,
            username: user.username
        },
        JWT_SECRET,
        {
            expiresIn: "12h"
        }
    );
}

function verifierAuth(req, res, next) {
    const authorization = req.headers.authorization || "";

    if (!authorization.startsWith("Bearer ")) {
        return res.status(401).json({
            ok: false,
            message: "Authentification requise."
        });
    }

    const token = authorization.slice("Bearer ".length).trim();

    try {
        req.user = jwt.verify(token, JWT_SECRET);
        return next();
    } catch (erreur) {
        return res.status(401).json({
            ok: false,
            message: "Session expirée ou jeton invalide."
        });
    }
}

/*
    À placer après app.use(express.json(...)) et AVANT les routes protégées.
*/

app.post("/api/auth/login", async (req, res) => {
    try {
        const username = String(req.body?.username || "").trim();
        const password = String(req.body?.password || "");

        if (!username || !password) {
            return res.status(400).json({
                ok: false,
                message: "Utilisateur et mot de passe obligatoires."
            });
        }

        const resultat = await pool.query(
            "SELECT id, username, password_hash FROM app_user WHERE username = $1",
            [username]
        );

        if (resultat.rowCount === 0) {
            return res.status(401).json({
                ok: false,
                message: "Utilisateur ou mot de passe invalide."
            });
        }

        const user = resultat.rows[0];
        const motDePasseValide = await bcrypt.compare(password, user.password_hash);

        if (!motDePasseValide) {
            return res.status(401).json({
                ok: false,
                message: "Utilisateur ou mot de passe invalide."
            });
        }

        return res.json({
            ok: true,
            username: user.username,
            token: creerTokenUtilisateur(user)
        });

    } catch (erreur) {
        console.error("Erreur login :", erreur);
        return res.status(500).json({
            ok: false,
            message: "Erreur serveur pendant l'authentification.",
            details: erreur.message
        });
    }
});

app.get("/api/auth/me", verifierAuth, async (req, res) => {
    return res.json({
        ok: true,
        id: req.user.id,
        username: req.user.username
    });
});

/*
    Protection des routes existantes.

    À placer AVANT les définitions de ces routes :
    app.get("/api/captures", ...)
    app.post("/api/captures", ...)
    app.post("/api/analyze-vision-pro", ...)
    app.post("/api/analyse-technique-pro", ...)
    app.post("/api/vider-captures", ...)
    app.delete("/api/vider-captures", ...)
*/

app.use("/api/captures", verifierAuth);
app.use("/api/analyze-vision-pro", verifierAuth);
app.use("/api/analyse-technique-pro", verifierAuth);
app.use("/api/vider-captures", verifierAuth);

/*
    À appeler au démarrage du serveur, après la création de pool.
    Exemple :
    creerTableUtilisateursSiBesoin()
        .then(() => console.log("Table utilisateurs vérifiée."))
        .catch((erreur) => console.error("Erreur création table utilisateurs :", erreur));
*/

creerTableUtilisateursSiBesoin()
    .then(() => console.log("Table utilisateurs vérifiée."))
    .catch((erreur) => console.error("Erreur création table utilisateurs :", erreur));
