-- Table d'authentification
-- Ne pas stocker de mot de passe en clair.
-- La colonne password_hash contient le mot de passe chiffré avec bcrypt.

CREATE TABLE IF NOT EXISTS app_user (
    id SERIAL PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    date_creation TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_app_user_username ON app_user(username);
