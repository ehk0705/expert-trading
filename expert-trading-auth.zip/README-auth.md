# Authentification Expert Trading Pro

## Fichiers

- `index-auth.html` : version modifiée de `index.html` avec écran de connexion.
- `auth-a-ajouter-server.js` : bloc à intégrer dans `server.js`.
- `auth-table.sql` : création de la table PostgreSQL.

## Dépendances Node.js

Dans le dossier du projet :

```bash
npm install bcryptjs jsonwebtoken
```

Puis vérifier que `package.json` contient :

```json
"bcryptjs": "^2.4.3",
"jsonwebtoken": "^9.0.2"
```

## Variables d'environnement Render

Ajouter dans Render :

```text
JWT_SECRET=une_phrase_longue_et_unique
AUTH_ADMIN_USER=admin
AUTH_ADMIN_PASSWORD=mot_de_passe_solide
```

Au premier démarrage, le serveur crée automatiquement la table `app_user` et le premier utilisateur si celui-ci n'existe pas.

## Sécurité

Le fichier HTML ne suffit pas. Les routes API doivent être protégées côté serveur avec le middleware `verifierAuth`.
